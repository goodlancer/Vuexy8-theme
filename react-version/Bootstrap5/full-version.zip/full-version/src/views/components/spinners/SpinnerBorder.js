// ** Reactstrap Imports
import { Spinner } from 'reactstrap'

const SpinnerBorder = () => {
  return <Spinner />
}
export default SpinnerBorder
