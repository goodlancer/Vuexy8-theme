// ** Reactstrap Imports
import { Spinner } from 'reactstrap'

const SpinnerGrowing = () => {
  return <Spinner type='grow' />
}
export default SpinnerGrowing
